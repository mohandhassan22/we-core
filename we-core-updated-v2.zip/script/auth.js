/**
 * WE-Core Authentication Guard (V2 - High Priority)
 * This script ensures that the user is logged in before accessing any page.
 * If not logged in, it redirects to index.html immediately.
 */

(function() {
    // 1. Check if we are on the login page (index.html)
    const path = window.location.pathname;
    const isLoginPage = path.endsWith('index.html') || path === '/' || path.endsWith('.icu/') || path === '';

    // 2. Check for saved session in localStorage
    const savedUser = localStorage.getItem('we_user');

    if (!savedUser && !isLoginPage) {
        // Stop rendering content if possible
        if (document.documentElement) {
            document.documentElement.style.display = 'none';
        }
        
        // Determine the path to the root index.html
        // For we-core.icu/pdf.html -> depth is 0, path is index.html
        // For we-core.icu/info/ardy.html -> depth is 1, path is ../index.html
        
        const depth = (path.match(/\//g) || []).length - 1;
        let rootPath = 'index.html';
        if (depth > 0) {
            rootPath = '../'.repeat(depth) + 'index.html';
        }
        
        // Immediate redirect
        window.location.replace(rootPath);
    }
})();
